//
//  ViewController.swift
//  ConcentrationLSG
//  Copyright © 2019 CFGS La Salle Gracia. All rights reserved.
//

import UIKit

class ViewController: UIViewController {


}


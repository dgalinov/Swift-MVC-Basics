//
//  CalculatorBrain.swift
//  Calculator
//
//  Created by Dragomir on 28/02/2019.
//  Copyright © 2019 Dragomir La Salle Gracia. All rights reserved.
//

import Foundation

class CalculatorBrain {
    // Definimos el display suma que se va a mostrar por pantalla
    private var acumulador: Float = 0;
    private var display: Float = 0;
    private var rewrite: Bool = true;
    private var operador = 0;
    
    //Definir los static finals
    public static let SUMA: Int = 1;
    public static let RESTA: Int = 2;
    public static let MULTIPLICA: Int = 3;
    public static let DIVIDE: Int = 4;
    public static let IGUAL: Int = 5;
    public static let NADA: Int = 0;
    
    // Creamos las funciones
    init()
    {
        self.reset()
    }
    
    func reset() -> Void
    {
        display = 0;
        acumulador = 0;
        operador = CalculatorBrain.NADA;
    }
    
    func getDisplay() -> Float {
        return display;
    }
    
    func setNumber(n: Int) -> Void {
        if rewrite {
            display = 0;
            rewrite = false;
        }
        display = display * 10 + Float(n);
    }
    
    func setOperation(op: Int) -> Void {
        updateValue(op: op);
        operador = op;
        rewrite = true;
    }
    
    func result() -> Void {
        updateValue(op: CalculatorBrain.IGUAL);
        operador = CalculatorBrain.NADA;
        rewrite = true;
    }
    
    private func updateValue(op: Int) -> Void {
        switch operador {
            case CalculatorBrain.NADA:
                acumulador = display;
                break;
            case CalculatorBrain.SUMA:
                acumulador = acumulador + display;
                break;
            case CalculatorBrain.RESTA:
                acumulador = acumulador - display;
                break;
            case CalculatorBrain.MULTIPLICA:
                acumulador = acumulador * display;
                break;
            case CalculatorBrain.DIVIDE:
                acumulador = acumulador / display;
                break;
            default:
                break;
        }
        display = acumulador;
    }
}
